module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // Add all your file extensions here
  ],
  theme: {
    extend: {}, // Customize your theme here
  },
  plugins: [], // Add plugins if needed
};
